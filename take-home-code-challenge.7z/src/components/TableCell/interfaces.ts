export interface TableCellProps {
  header?: boolean,
  scope?: string
}